from django.contrib import admin
from .models import*

# admin.site.register(Document)
# admin.site.register(Signature)
# admin.site.register(SignaturePlacement)
# admin.site.register(SigningToken)

